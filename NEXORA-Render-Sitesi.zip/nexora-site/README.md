# NEXORA

NEXORA için hazırlanmış, Render Static Site üzerinde ücretsiz yayınlanmaya uygun tek sayfalık Türkçe tanıtım sitesi.

## Render ayarları

- Service type: Static Site
- Build command: boş
- Publish directory: `.`

`render.yaml` dosyası bu ayarları otomatik olarak tanımlar.
