NEXORA Wi-Fi Connect - TURKCELL MARINACELL

Kurulum:
1. index.html dosyasını statik site olarak Render/GitHub Pages vb. HTTPS servisine yükleyin.
2. Açılan HTTPS adresini NFC etikete URL (NDEF URI) olarak yazın.
3. NFC ile sayfa açılır. Bağlan düğmesi bağlantı talimatlarını gösterir; şifre kopyalama düğmesi şifreyi kopyalar.

ÖNEMLİ: Tarayıcı tek başına iPhone/Android Wi-Fi ağına otomatik bağlanamaz. Bu sayfa şifreyi JavaScript içinde içerir; yayınlandığında herkes görüntüleyebilir. Yalnızca paylaşılabilir MİSAFİR ağı kullanın, ana/özel işletme ağının şifresini bu şekilde yayınlamayın. Yayınlamadan önce misafir ağı oluşturulması önerilir.
